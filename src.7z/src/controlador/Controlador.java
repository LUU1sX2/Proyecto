/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

/**
 *
 * @author Jose Luis
 */
public class Controlador {
    //Controla el flujo del juego: recibe eventos de botones, actualiza el tablero y valida movimientos legales.
}
