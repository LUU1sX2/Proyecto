/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;
import modelo.Ficha;
/**
 *
 * @author Jose Luis
 */
public class MovimientoRealizado {
    public Ficha origen, intermedia, destino;
    public MovimientoRealizado(Ficha o, Ficha i, Ficha d) {
        this.origen = o;
        this.intermedia = i;
        this.destino = d;
    }
    
}
